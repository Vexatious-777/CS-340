
from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """
    def __init__(self, USER, PASS):
        # Intializing the MongoClient. This helps to
        # access the MongoDB databases and collections.
        # This is hardwired to use the aac database, the
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = USER
        PASS = PASS
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32639
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % DB]
        self.collection = self.database['%s' % COL]
        
    def test_connection(self):
        try:
            collection_list = self.database.list_collection_names()
            print(f"Test: {collection_list}") # print to ensure that the correct database was selected
            return True
        except Exception as e: # Error Check
            print(f"Error: {e}")
            return False
        
        # Complete this create method to implement the C in CRUD. (Create)
    def create(self, data):
        if isinstance(data, dict) and data: # this should ensure that the data is a dictionary as well as a check for null values through boolean check
            try:
                result = self.collection.insert_one(data) # data should be dictionary
                acknowledged = result.acknowledged
                
                print(acknowledged)
                return acknowledged
            
            except Exception as e:
                print(f'error: {e}')
            return False
        else:
            print("Nothing to save, because data parameter is empty")
            return False
                
                # Create method to implement the R in CRUD
    def read(self, query, projection=None):
        
        if query is None:
            query = {}   #to ensure the query won't lead to a fail state by defaulting to an empty dictionary
        
        if projection is None:
            projection = {}
            
        try:
            results = self.collection.find(query)
            
            documents = list(results)
            
            return documents
        except Exception as e:
            print(f"Error: {e}")
            return []
        
    def update(self, query, update_values):
        try:
                    
            update_action = {"$set": update_values}
                    
            result = self.collection.update_one(query, update_action)
                    
            if result.modified_count > 0:
                print(f"Document(s) Modified: {result.modified_count}")
                return True
                    
            else:
                print("Update failed")
                return False
        except Exception as e:
            print(f"Error: {e}")
            return False

    def destroy(self, query):
            
        try:
            
            result = self.collection.delete_one(query)
            
            if result.deleted_count > 0:
                print(f"Document(s) Deleted: {result.deleted_count}")
                return True
            else:
                print("No Target Documents Found")
                return False
        except Exception as e:
            print(f"Error: {e}")
            return False